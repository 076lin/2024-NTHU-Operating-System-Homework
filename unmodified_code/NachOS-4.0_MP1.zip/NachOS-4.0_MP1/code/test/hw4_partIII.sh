#!/bin/sh
../build.linux/nachos -f
../build.linux/nachos -mkdir /t0
../build.linux/nachos -mkdir /t1
../build.linux/nachos -cp num_100.txt /t0/f1
../build.linux/nachos -mkdir /t0/aa
../build.linux/nachos -cp num_100.txt /t0/aa/f1
../build.linux/nachos -l /
echo ===================
../build.linux/nachos -lr /
