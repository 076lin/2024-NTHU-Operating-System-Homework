../build.linux/nachos -f
../build.linux/nachos -cp num_1000.txt /1000
../build.linux/nachos -p /1000
